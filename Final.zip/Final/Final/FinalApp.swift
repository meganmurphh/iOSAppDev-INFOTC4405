//
//  FinalApp.swift
//  Final
//
//  Created by Megan Murphy on 12/7/23.
//

import SwiftUI

@main
struct FinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
