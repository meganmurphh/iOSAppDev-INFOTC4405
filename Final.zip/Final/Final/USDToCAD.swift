//
//  USDToCAD.swift
//  Final
//
//  Created by Megan Murphy on 12/8/23.
//

import SwiftUI

struct USDToCAD: View {
    @State private var userInput: String = ""
    @State private var result: String = ""
    @State private var contentSize: CGSize = .zero

    var body: some View {
        ScrollView([.vertical]){
            
            VStack {
                
                Image("worldmap")
                
                Image("canada")
                    .resizable()
                    .frame(width: 520, height:310)
                    .padding(.top, -250)
                    .padding(.bottom, 100)
                    .shadow(radius: 7)
                
                HStack {
                    Text("$")
                        .padding(.leading)
                        .font(.system(size: 50))
                        .padding(.top, -75)
                    
                    TextField("Enter a number", text: $userInput)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .font(.system(size: 50))
                        .keyboardType(.numberPad)
                        .padding(.top, -80)
        
                }
                
                Button("Convert", action: convertButtonTapped)
                    .padding(30)
                    .foregroundColor(.white)
                    .background(Color.red)
                    .cornerRadius(50)
                    .font(.system(size: 50))
                    .padding(.bottom, 20)
                
                Text("$\(userInput) equates to:")
                    .padding()
                    .font(.system(size: 50))
                
                Text(result)
                    .padding()
                    .font(.system(size: 50))
            }
            
            .scaleEffect(0.58)
            .padding(.top, -150)

            
        }
        .ignoresSafeArea()
        
    }

    func convertButtonTapped() {

        guard let decimalNumber = Double(userInput) else {
            result = "Invalid input. Please enter a valid number."
            return
        }
        
        let pesos = decimalNumber * 1.36

        result = "$\(String(format: "%.2f", pesos))"
    }
}

#Preview {
    USDToCAD()
}
