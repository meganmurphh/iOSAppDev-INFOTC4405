//
//  CurrList.swift
//  Final
//
//  Created by Megan Murphy on 12/7/23.
//

import SwiftUI

struct CurrList: View {
    var body: some View {
        Text("Foreign Currency Converter")
            .font(.system(size: 30))
        NavigationView{
            List{
                NavigationLink{
                    USDToMXN()
                } label: {
                    Text("₱ (PESO)")
                        .font(.system(size: 30))
                }
                NavigationLink{
                    USDToINR()
                } label: {
                    Text("₹ (RUPEE)")
                        .font(.system(size: 30))
                }
                NavigationLink{
                    USDToJPY()
                } label: {
                    Text("¥ (YEN)")
                        .font(.system(size: 30))
                }
                NavigationLink{
                    USDToEUR()
                } label: {
                    Text("€ (EURO)")
                        .font(.system(size: 30))
                }
                NavigationLink{
                    USDToUK()
                } label: {
                    Text("£ (POUND)")
                        .font(.system(size: 30))
                }
                NavigationLink{
                    USDToAUD()
                } label: {
                    Text("AU$ (AUS DOLLAR)")
                        .font(.system(size: 30))
                }
                NavigationLink{
                    USDToCAD()
                } label: {
                    Text("CA$ (CAN DOLLAR)")
                        .font(.system(size: 30))
                }
                
            }
            
        }.navigationTitle("Back")
        
    }
}

#Preview {
    CurrList()
}
