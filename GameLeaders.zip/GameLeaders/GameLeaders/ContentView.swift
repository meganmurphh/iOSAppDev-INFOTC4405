//
//  ContentView.swift
//  GameLeaders
//
//  Created by Megan Murphy on 10/4/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Divider()
            Text("Passing Yards")
                .bold()
                .padding(.top, 7.0)
                .padding(.bottom, -20.0)
            HStack{
                GameLeaderLeft(player:"hooker", name:"H. Hooker", record: "15-19,", career: "225 YDS, 3 TD", team: "TENN", interceptions: nil)
                Divider()
                    .frame(height: 80)
                GameLeaderRight(player: "bazelak", name: "C. Bazelak", record: "27-44,", career: "322 YDS,", team: "MIZ", interceptions: "2 INT")
            }
            Divider()
                .padding(.top, -10)
            Text("Rushing Yards")
                .bold()
                .padding(.top, 4.0)
                .padding(.bottom, -20.0)
            HStack{
                GameLeaderLeft(player:"evans", name:"T. Evans", record: "15 CAR,", career: "156 YDS, 3 TD", team: "TENN", interceptions: nil)
                Divider()
                    .frame(height: 80)
                GameLeaderRight(player: "badie", name: "T. Badie", record: "21 CAR,", career: "41 YDS, 1 TD", team: "MIZ", interceptions: nil)
            }
            Divider()
                .padding(.top, -10)
            Text("Receiving Yards")
                .bold()
                .padding(.top, 7.0)
                .padding(.bottom, -30.0)
            HStack{
                GameLeaderLeft(player:"jones", name:"V. Jones Jr.", record: "7 REC,", career: "79 YDS, 1 TD", team: "TENN", interceptions: nil)
                Divider()
                    .frame(height: 80)
                GameLeaderRight(player: "chism", name: "K. Chism", record: "4 REC, 76 YDS", career: "", team: "MIZ", interceptions: nil)
            }
            Divider()
                .padding(.top, -10)
        }
    }
}

#Preview {
    ContentView()

}
