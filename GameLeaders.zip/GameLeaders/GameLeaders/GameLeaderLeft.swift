//
//  GameLeaderLeft.swift
//  GameLeaders
//
//  Created by Megan Murphy on 10/4/23.
//

import SwiftUI

struct GameLeaderLeft: View {
    var player: String
    var name: String
    var record: String
    var career: String?
    var team: String
    var interceptions: String?
    
    init(player: String, name: String, record: String, career: String?, team: String, interceptions: String?){
        self.player = player
        self.name = name
        self.record = record
        self.career = career
        self.team = team
        self.interceptions = interceptions
    }
    
    var body: some View {
        VStack{
            HStack{
                VStack{
                    Image(player)
                        .resizable()
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.gray, lineWidth: 1))
                    Text(team)
                        .font(.system(size: 12))
                }.padding(.trailing, 10)
                VStack(alignment: .trailing){
                    Text(name)
                        .bold()
                        .font(.system(size: 15))
                        .minimumScaleFactor(0.5)
                    Text(record)
                        .font(.system(size: 13))
                    if let unwrappedCareer = career {
                        Text(unwrappedCareer)
                            .font(.system(size: 13))                        
                    }
                    Text(interceptions ?? "")
                        .font(.system(size: 13))
                }.frame(height: 100)
                
            }
            .frame(width: 170)
            .padding(.trailing, -20)
        }
        .padding()
    }
        
}


#Preview {
    GameLeaderLeft(player:"hooker", name:"H. Hooker", record: "15-19", career: "225 YDS, 3 TD", team: "TENN", interceptions: nil)
}
